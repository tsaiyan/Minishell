// #include "header.h"





// static void ft_puts_double_array(char **str)
// {
// 	int i;

// 	i = 0;
// 	while (bin->envp[i])
// 		ft_puts(bin->envp[i++]);
// }
// void ft_export4(t_bin *bin)
// {
// 	sort_export (bin);
// 	ft_puts_double_array(bin->envp);
// }